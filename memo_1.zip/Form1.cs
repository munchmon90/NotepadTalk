﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;


namespace memo_1
{

    public partial class Form1 : Form
    {



        [DllImport("user32.dll")]
        private static extern int FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        public static extern int FindWindowEx(int hWnd1, int hWnd2, string lpsz1, string lpsz2);

        [DllImport("user32.dll")]
        public static extern int SendMessage(int hwnd, int wMsg, int wParam, string lParam);

        [DllImport("user32.dll")]
        public static extern uint PostMessage(int hwnd, int wMsg, int wParam, int lParam);

        [DllImport("user32.dll")]
        public static extern uint ChatLoad(int hwnd, int wMsg, int wParam, int lParam);

        [DllImport("user32.dll")]
        public static extern uint Menu_Friend(int hwnd, int wMsg, int wParam, int lParam);



        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(int hWnd);


        const int WM_KEYDOWN = 0x100;
        const int WM_KEYUP = 0x101;
        const Int32 VK_RETURN = 0x0D;
        const int VK_ENTER = 0x0D;
        const int VK_CONTROL = 0xA2;
        const int VK_A = 0x41;
        const int VK_C = 0x43;
        const int VK_V = 0x56;
        const int VK_SHIFT = 0x10;
        const int VK_TAB = 0x09;
        

        
        //int msgCount = 0;

        public Form1()
        {
            InitializeComponent();

            this.friend_list_cbox.SelectedIndexChanged += friend_list_cbox_SelectedIndexChanged;
            load_list();
            
        }




        public void load_list()
        {
            friend_list_cbox.Items.Clear();
            
            StreamReader sr;
            sr = new StreamReader(System.Environment.CurrentDirectory + @"f_list.dat", Encoding.UTF8);
            string line;
            while((line = sr.ReadLine()) != null)
            {
                friend_list_cbox.Items.Add(line);
            }
            sr.Close();

        }




        public void SendMessage(string title, string msg)
        {
            int hd01 = FindWindow(null, title);
            
            //SetForegroundWindow(hd01);
            int hd03 = FindWindowEx(hd01, 0, "RichEdit50W", "");
            SendMessage(hd03, 0x000c, 0, msg);
            PostMessage(hd03, 0x0100, 0xD, 0x1C001);
            System.Threading.Thread.Sleep(10);
            
        }

        public void ChatLoad(string title)
        {

            int hd01 = FindWindow(null, title);
            //SetForegroundWindow(hd01);
            int hd03 = FindWindowEx(hd01, 0, "EVA_VH_ListControl_Dblclk", "");
            int sleep_time = 10;

            //전체 선택
            PostMessage(hd03, 0x07E9, (int)(Convert.ToInt64("65", 16)), 0);
            System.Threading.Thread.Sleep(sleep_time);

            //복사
            PostMessage(hd03, 0x07E9, (int)(Convert.ToInt64("64", 16)), 0);
            System.Threading.Thread.Sleep(sleep_time);
                 
            //빈 곳 클릭
            PostMessage(hd03, 0x201, 00000002, (int)(Convert.ToInt64("002B0007", 16)));
            PostMessage(hd03, 0x202, 00000002, (int)(Convert.ToInt64("002B0007", 16)));
            System.Threading.Thread.Sleep(sleep_time);

            //this.chat_textbox.Text = System.Windows.Forms.Clipboard.GetText();


        }

        

        public void ChatUpdate()
        {


            string msg = System.Windows.Forms.Clipboard.GetText();
            string[] copy_chat = msg.Split('\n');

            string orign_msg = this.chat_textbox.Text;
            string[] origin_chat = orign_msg.Split('\n');

            IEnumerable<string> new_chat = copy_chat.Except(origin_chat);
            
            foreach (string chat in new_chat)
            {
                chat_textbox.AppendText(chat + Environment.NewLine);
            }
            
            

            // this.chat_textbox.Text = System.Windows.Forms.Clipboard.GetText();
            //Clipboard.Clear();
            //string msg = System.Windows.Forms.Clipboard.GetText();
            //string[] arr = msg.Split('\n');


            //List<string> list = new List<string>();
            //list = arr.ToList();


            //string orign_msg = this.chat_textbox.Text;
            //string[] origin_arr = orign_msg.Split('\n');

            //List<string> list2 = new List<string>();
            //list2 = origin_arr.ToList();

            //list = list.Except(list2).ToList();

            //List<string> list3 = new List<string>();


            //for (int i = 0; i < list.Count; i++)
            //{

            //    //this.chat_textbox.Text += list[i] + Environment.NewLine;
            //    this.chat_textbox.AppendText(list[i] + Environment.NewLine);

            //}

            //list.Clear();
            //list2.Clear();
            //chat_textbox.Select(chat_textbox.TextLength, 0);
            //chat_textbox.ScrollToCaret();

        }

        public void Check_ChatRoom(string title)
        {
                
        }

        public void Menu_Friend()
        {
            int sleep_time = 10;

            int hd01 = FindWindow(null, "카카오톡");
            SetForegroundWindow(hd01);
            int hd02 = FindWindowEx(hd01, 0, "EVA_ChildWindow", "");
            System.Threading.Thread.Sleep(sleep_time);
            int hd03 = FindWindowEx(hd02, 0, "EVA_Window", "");
            System.Threading.Thread.Sleep(sleep_time);
            PostMessage(hd03, 0x201, (int)(Convert.ToInt64("0002044E", 16)), (int)(Convert.ToInt64("02010001", 16)));
            PostMessage(hd03, 0x202, (int)(Convert.ToInt64("0002044E", 16)), (int)(Convert.ToInt64("02010001", 16)));
            System.Threading.Thread.Sleep(sleep_time);





            //int hd02 = FindWindowEx(hd01, 0, "EVA_ChildWindow", "");
            //int hd03 = FindWindowEx(hd02, 0, "EVA_Window", "");
            //int hd04 = FindWindowEx(hd03, 0, "Edit", "");

            //SendMessage(hd04, 0x000c, 0, "asd");
            //PostMessage(hd03, 0x0118, (int)(Convert.ToInt64("0000FFFF", 16)), (int)(Convert.ToInt64("00000118", 16)));


            //int hd01 = FindWindow(null, "카카오톡");
            //SetForegroundWindow(hd01);
            //int hd02 = FindWindowEx(hd01, 0, "EVA_ChildWindow", "");
            //int hd03 = FindWindowEx(hd02, 0, "EVA_Window", "");
            //int hd04 = FindWindowEx(hd)

            //PostMessage(hd03, 0x201, 00020096, 02010001);
            //PostMessage(hd03, 0x202, 00020096, 02010001);

            //PostMessage(hd02, 0x202, 00000201, (int)(Convert.ToInt64("003601C5",16)));

            System.Threading.Thread.Sleep(sleep_time);
        }


        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox1.TextLength > 0)
                {
                    if (friend_list_cbox.SelectedItem == null)
                    {
                        this.chat_textbox.Text += textBox1.Text + Environment.NewLine;
                    }

                    if (friend_list_cbox.SelectedItem != null)
                    {
                        SendMessage(friend_list_cbox.SelectedItem.ToString(), textBox1.Text);

                        ChatLoad(friend_list_cbox.SelectedItem.ToString());
                        
                        ChatUpdate();

                        //Clipboard.Clear();
                        System.Threading.Thread.Sleep(10);

                        int hd04 = FindWindow(null, friend_list_cbox.SelectedItem.ToString() + " - Windows 메모장");
                        SetForegroundWindow(hd04);
                    }
                    this.textBox1.Clear();
                }   
            }
        }

        private void 추가ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 newform2 = new Form2(this);
            newform2.ShowDialog();
        }
                


        private void friend_list_cbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (friend_list_cbox.Items.Count >= 1)
            {
                this.Text = friend_list_cbox.SelectedItem.ToString() + " - Windows 메모장";
                ChatLoad(friend_list_cbox.SelectedItem.ToString());
                this.chat_textbox.Text = System.Windows.Forms.Clipboard.GetText();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            

          
        }
    }

}